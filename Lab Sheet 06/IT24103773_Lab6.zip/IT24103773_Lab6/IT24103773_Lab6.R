setwd('C:\\Users\\DELL\\OneDrive\\Desktop\\IT24103773_Lab6')

# Q1
n <- 50
p <- 0.85

# ii. P(X >= 47)
prob_q1 <- sum(dbinom(47:50, size = n, prob = p))
prob_q1

# Q2
lambda <- 12

# i. X = number of calls received in an hour
# ii. Distribution: Poisson(12)

# iii. P(X = 15)
prob_q2 <- dpois(15, lambda = lambda)
prob_q2
