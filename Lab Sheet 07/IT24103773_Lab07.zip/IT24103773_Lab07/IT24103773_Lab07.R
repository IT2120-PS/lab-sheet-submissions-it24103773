setwd('C:\\Users\\DELL\\OneDrive\\Desktop\\IT24103773_Lab07')

# Q1
prob_q1 <- (25 - 10) / 40
prob_q1

# Q2
lambda <- 1/3
prob_q2 <- 1 - exp(-lambda * 2)
prob_q2

# Q3 part1
mu <- 100; sigma <- 15
prob_q3_i <- 1 - pnorm(130, mean = mu, sd = sigma)
prob_q3_i

# Q3 part2
mu <- 100; sigma <- 15
z95 <- qnorm(0.95)
iq95 <- mu + z95 * sigma
iq95

