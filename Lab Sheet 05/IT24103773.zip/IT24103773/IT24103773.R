setwd("C:\\Users\\it24103773\\Documents\\IT24103773-Lab 05")

# 1. Import the dataset   CHANGE THIS TO THE FILE NAME 
deliveryTime<-read.table("Exercise - Lab 05.txt", header=TRUE)
fix(deliveryTime)
attach(deliveryTime)

# 2. Histogram with 9 right-open intervals from 20 to 70
breaks <- seq(20, 70, length.out = 10)
hist(deliveryTime$Delivery_Time_.minutes., breaks = breaks, right = FALSE)

# 3. Comment on the shape of the distribution:
# The distrubution is almost symmetric. however it has a slight deviation towards the right side.
#(skewness to the right)

# 4. Cumulative frequency polygon (ogive)
freq <- hist(deliveryTime$Delivery_Time_.minutes., breaks = breaks, plot = FALSE, right = FALSE)
cum_freq <- cumsum(freq$counts)

x <- freq$breaks[-1]
plot(x, cum_freq, type = "o")